# ps5-fan-control

Small PS5 daemon payload ELF that sets the system fan temperature threshold through `/dev/icc_fan`.

It does not implement its own fan curve. The PS5 system fan driver still handles automatic fan speed changes; this payload only changes and re-applies the temperature threshold used by that driver.

## Usage

Send `ps5-fan-control.elf` to the console over TCP port `9021` after elfldr started.

The payload sets its process name to `ps5-fan-control.elf`. Launching it again kills the previous `ps5-fan-control.elf` process, then continues running as a restarted daemon.

While running, it periodically re-reads the config. If `enable=1`, it re-applies the target threshold. Status notifications are sent when `show_status=1`, regardless of `enable`. The period is controlled by `interval`.

Command-line netcat works too:

```sh
nc <PS5 IP address> 9021 < ps5-fan-control.elf
```

## Build

```sh
make
```

The Makefile defaults to:

```sh
PS5_PAYLOAD_SDK=/opt/ps5-payload-sdk
```

You can override it if needed:

```sh
make PS5_PAYLOAD_SDK=/path/to/ps5-payload-sdk
```

## Config

Create `fan_control.ini` in one of these locations:

```text
/mnt/usb0/fan_control.ini
/mnt/usb1/fan_control.ini
...
/mnt/usb7/fan_control.ini
/data/fan_control.ini
```

USB paths are checked first, from `usb0` to `usb7`. `/data/fan_control.ini` is used only if no USB config is found. If no config file exists anywhere, the daemon uses default values.

Only these keys are accepted:

```ini
target_temperature=70
enable=1
use_fahrenheit=0
show_status=0
interval=7
xmb_target_temperature=0
```

Comment lines beginning with `#` or `;` are ignored.

`use_fahrenheit` is optional and must be `0` or `1`; if omitted or invalid, it defaults to `0`. When `use_fahrenheit=1`, temperature values in config are interpreted as Fahrenheit and valid threshold ranges become `86` to `194`.

`target_temperature` must be an Arabic integer from `30` to `90` when using Celsius, or `86` to `194` when using Fahrenheit; if omitted or invalid, it defaults to `70` Celsius.

`xmb_target_temperature` is optional. `0` disables the separate XMB threshold. Otherwise it must be an Arabic integer in the same range as `target_temperature`; it is used when no Big App is running. If omitted or invalid, it defaults to `0`.

`enable` is optional and must be `0` or `1`; if omitted or invalid, it defaults to `1`. When `enable=0`, the daemon keeps running and re-reading config, but skips writing `/dev/icc_fan`.

`show_status` is optional and must be `0` or `1`; if omitted or invalid, it defaults to `0`.

`interval` is optional and must be an Arabic integer from `1` to `3600` seconds; if omitted or invalid, it defaults to `7`. It controls both threshold re-apply and status notification timing.

If no config file exists, `target_temperature` defaults to `70`, `xmb_target_temperature` defaults to `0`, `enable` defaults to `1`, `use_fahrenheit` defaults to `0`, `show_status` defaults to `0`, and `interval` defaults to `7`.

If a config file exists but one or more recognized values are invalid or missing, those values fall back to defaults. The daemon shows one combined notification:

```text
[fan-control]
Invalid params:
target_temperature
enable
```

See `fan_control.ini.example`.

## Credits

- **[etaHEN](https://github.com/etaHEN/etaHEN) by LightningMods:** `/dev/icc_fan` threshold ioctl behavior, temperature status APIs, and fan-control range references.
- **[Elf Arsenal](https://git.etawen.dev/soniciso/elf-arsenal) by SonicISO:** fan-control re-apply behavior and `/dev/icc_fan` implementation notes.
- **[ps5-payload-dev/sdk](https://github.com/ps5-payload-dev/sdk) by John Tornblom:** PS5 payload toolchain and system library stubs used to build the ELF.
- **[ps5-fan-threshold](https://github.com/zecoxao/ps5-fan-threshold) by zecoxao:** Similar repo but old.

## License

This project is licensed under GPLv3. See [LICENSE](LICENSE).
