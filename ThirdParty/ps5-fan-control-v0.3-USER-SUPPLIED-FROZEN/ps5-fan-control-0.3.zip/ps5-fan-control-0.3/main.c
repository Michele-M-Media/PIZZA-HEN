// SPDX-License-Identifier: GPL-3.0-only

#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <signal.h>
#include <stdbool.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/syscall.h>
#include <sys/sysctl.h>
#include <unistd.h>

#define DATA_CONFIG_PATH "/data/fan_control.ini"
#define FAN_DEVICE "/dev/icc_fan"
#define FAN_IOCTL_SET_THRESHOLD 0xC01C8F07
#define DEFAULT_THRESHOLD 70
#define MIN_THRESHOLD 30
#define MAX_THRESHOLD 90
#define MIN_THRESHOLD_FAHRENHEIT (MIN_THRESHOLD * 9 / 5 + 32)
#define MAX_THRESHOLD_FAHRENHEIT (MAX_THRESHOLD * 9 / 5 + 32)
#define USB_MAX_COUNT 8
#define PROCESS_NAME "ps5-fan-control.elf"
#define VERSION_STRING "v0.3"
#define DEFAULT_INTERVAL_SECONDS 7
#define MIN_INTERVAL_SECONDS 1
#define MAX_INTERVAL_SECONDS 3600

typedef struct {
    char useless1[45];
    char message[3075];
} notify_request_t;

typedef struct {
    int threshold_raw;
    int threshold;
    int interval;
    bool enable;
    bool show_status;
    int xmb_threshold_raw;
    int xmb_threshold;
    bool use_fahrenheit;
    unsigned int defaults_used;

} fan_config_t;

typedef enum {
    CONFIG_MISSING,
    CONFIG_VALID
} config_read_result_t;

#define DEFAULT_USED_TARGET      0x01
#define DEFAULT_USED_ENABLE      0x02
#define DEFAULT_USED_SHOW_STATUS 0x04
#define DEFAULT_USED_INTERVAL    0x08
#define DEFAULT_USED_XMB_TARGET  0x10
#define DEFAULT_USED_FAHRENHEIT  0x20

int sceKernelSendNotificationRequest(int, notify_request_t *, size_t, int);
int sceKernelGetCpuTemperature(int *out_celsius);
int sceKernelGetSocSensorTemperature(int sensor_id, int *out_celsius);
int sceKernelGetCurrentFanDuty(uint16_t *out_duty, void *scratch);
int sceSystemServiceGetAppIdOfRunningBigApp();

static void notify(const char *fmt, ...) {
    notify_request_t req;
    va_list args;

    memset(&req, 0, sizeof(req));
    va_start(args, fmt);
    vsnprintf(req.message, sizeof(req.message), fmt, args);
    va_end(args);

    sceKernelSendNotificationRequest(0, &req, sizeof(req), 0);
}

static pid_t find_pid_by_name(const char *name) {
    int mib[4] = {1, 14, 8, 0};
    pid_t mypid = getpid();
    pid_t found = -1;
    size_t buf_size = 0;
    uint8_t *buf;

    if (sysctl(mib, 4, NULL, &buf_size, NULL, 0) != 0) {
        return -1;
    }

    buf = malloc(buf_size);
    if (buf == NULL) {
        return -1;
    }

    if (sysctl(mib, 4, buf, &buf_size, NULL, 0) != 0) {
        free(buf);
        return -1;
    }

    for (uint8_t *ptr = buf; ptr < buf + buf_size;) {
        int ki_structsize = *(int *)ptr;
        pid_t ki_pid = *(pid_t *)&ptr[72];
        char *ki_tdname = (char *)&ptr[447];

        ptr += ki_structsize;
        if (ki_structsize <= 0) {
            break;
        }

        if (ki_pid != mypid && strcmp(name, ki_tdname) == 0) {
            found = ki_pid;
        }
    }

    free(buf);
    return found;
}

static bool stop_previous_instances(bool *stopped) {
    pid_t pid;

    *stopped = false;
    while ((pid = find_pid_by_name(PROCESS_NAME)) > 0) {
        if (kill(pid, SIGKILL) != 0) {
            notify("[fan-control] Failed to kill old daemon pid %d", pid);
            return false;
        }
        *stopped = true;
        sleep(1);
    }

    return true;
}

static void trim(char *s) {
    char *start = s;
    size_t len;

    while (*start == ' ' || *start == '\t' || *start == '\r' || *start == '\n') {
        start++;
    }

    if (start != s) {
        memmove(s, start, strlen(start) + 1);
    }

    len = strlen(s);
    while (len > 0 &&
           (s[len - 1] == ' ' || s[len - 1] == '\t' || s[len - 1] == '\r' || s[len - 1] == '\n')) {
        s[--len] = '\0';
    }
}

static bool parse_int_value(const char *s, int *out) {
    char *end = NULL;
    long value;

    errno = 0;
    value = strtol(s, &end, 10);
    if (errno != 0 || end == s || value < INT_MIN || value > INT_MAX) {
        return false;
    }

    while (*end == ' ' || *end == '\t' || *end == '\r' || *end == '\n') {
        end++;
    }
    if (*end != '\0') {
        return false;
    }

    *out = (int)value;
    return true;
}

static int fahrenheit_to_celsius(int fahrenheit)
{
    return (fahrenheit - 32) * 5 / 9;
}

static bool parse_config_line(char *line, fan_config_t *config) {
    char *eq;
    char *key;
    char *value;
    int parsed_value;

    trim(line);
    if (line[0] == '\0' || line[0] == '#' || line[0] == ';' || line[0] == '[') {
        return false;
    }

    eq = strchr(line, '=');
    if (eq == NULL) {
        return false;
    }

    *eq = '\0';
    key = line;
    value = eq + 1;
    trim(key);
    trim(value);

    if (strcmp(key, "target_temperature") == 0) {
        if (!parse_int_value(value, &parsed_value)) {
            config->threshold_raw = 0;
            config->defaults_used |= DEFAULT_USED_TARGET;
            return false;
        }

        config->threshold_raw = parsed_value;
        config->defaults_used &= ~DEFAULT_USED_TARGET;
        return true;
    }

    if (strcmp(key, "show_status") == 0) {
        if (!parse_int_value(value, &parsed_value) ||
            (parsed_value != 0 && parsed_value != 1)) {
            config->show_status = false;
            config->defaults_used |= DEFAULT_USED_SHOW_STATUS;
            return false;
        }

        config->show_status = (parsed_value == 1);
        config->defaults_used &= ~DEFAULT_USED_SHOW_STATUS;
        return true;
    }

    if (strcmp(key, "enable") == 0) {
        if (!parse_int_value(value, &parsed_value) ||
            (parsed_value != 0 && parsed_value != 1)) {
            config->enable = true;
            config->defaults_used |= DEFAULT_USED_ENABLE;
            return false;
        }

        config->enable = (parsed_value == 1);
        config->defaults_used &= ~DEFAULT_USED_ENABLE;
        return true;
    }

    if (strcmp(key, "interval") == 0) {
        if (!parse_int_value(value, &parsed_value) ||
            parsed_value < MIN_INTERVAL_SECONDS ||
            parsed_value > MAX_INTERVAL_SECONDS) {
            config->interval = DEFAULT_INTERVAL_SECONDS;
            config->defaults_used |= DEFAULT_USED_INTERVAL;
            return false;
        }

        config->interval = parsed_value;
        config->defaults_used &= ~DEFAULT_USED_INTERVAL;
        return true;
    }

    if (strcmp(key, "xmb_target_temperature") == 0) {
        if (!parse_int_value(value, &parsed_value) ||
            parsed_value < 0) {
            config->xmb_threshold_raw = 0;
            config->defaults_used |= DEFAULT_USED_XMB_TARGET;
            return false;
        }

        config->xmb_threshold_raw = parsed_value;
        config->defaults_used &= ~DEFAULT_USED_XMB_TARGET;
        return true;
    }

    if (strcmp(key, "use_fahrenheit") == 0) {
        if (!parse_int_value(value, &parsed_value) ||
            (parsed_value != 0 && parsed_value != 1)) {
            config->use_fahrenheit = false;
            config->defaults_used |= DEFAULT_USED_FAHRENHEIT;
            return false;
        }

        config->use_fahrenheit = (parsed_value == 1);
        config->defaults_used &= ~DEFAULT_USED_FAHRENHEIT;
        return true;
    }

    return false;
}

static void apply_config(fan_config_t *config) {
    if (config->use_fahrenheit) {
        if (config->defaults_used & DEFAULT_USED_TARGET) {
            config->threshold = DEFAULT_THRESHOLD;
        } else if (config->threshold_raw < MIN_THRESHOLD_FAHRENHEIT || config->threshold_raw > MAX_THRESHOLD_FAHRENHEIT) {
            config->threshold = DEFAULT_THRESHOLD;
            config->defaults_used |= DEFAULT_USED_TARGET;
        } else {
            config->threshold = fahrenheit_to_celsius(config->threshold_raw);
        }

        if (config->xmb_threshold_raw > 0) {
            if (config->defaults_used & DEFAULT_USED_XMB_TARGET) {
                config->xmb_threshold = 0;
            } else if (config->xmb_threshold_raw < MIN_THRESHOLD_FAHRENHEIT || config->xmb_threshold_raw > MAX_THRESHOLD_FAHRENHEIT) {
                config->xmb_threshold = 0;
                config->defaults_used |= DEFAULT_USED_XMB_TARGET;
            } else {
                config->xmb_threshold = fahrenheit_to_celsius(config->xmb_threshold_raw);
            }
        }
    } else {
        if (config->defaults_used & DEFAULT_USED_TARGET) {
            config->threshold = DEFAULT_THRESHOLD;
        } else if (config->threshold_raw < MIN_THRESHOLD || config->threshold_raw > MAX_THRESHOLD) {
            config->threshold = DEFAULT_THRESHOLD;
            config->defaults_used |= DEFAULT_USED_TARGET;
        } else {
            config->threshold = config->threshold_raw;
        }

        if (config->xmb_threshold_raw > 0) {
            if (config->defaults_used & DEFAULT_USED_XMB_TARGET) {
                config->xmb_threshold = 0;
            } else if (config->xmb_threshold_raw < MIN_THRESHOLD || config->xmb_threshold_raw > MAX_THRESHOLD) {
                config->xmb_threshold = 0;
                config->defaults_used |= DEFAULT_USED_XMB_TARGET;
            } else {
                config->xmb_threshold = config->xmb_threshold_raw;
            }
        }
    }
}

static config_read_result_t read_config_from_path(const char *path, fan_config_t *config_out) {
    FILE *fp;
    char line[256];
    fan_config_t config;

    fp = fopen(path, "r");
    if (fp == NULL) {
        return CONFIG_MISSING;
    }

    config.threshold = DEFAULT_THRESHOLD;
    config.threshold_raw = 0;
    config.interval = DEFAULT_INTERVAL_SECONDS;
    config.enable = true;
    config.show_status = false;
    config.xmb_threshold = 0;
    config.xmb_threshold_raw = 0;
    config.use_fahrenheit = false;
    config.defaults_used = 0;

    while (fgets(line, sizeof(line), fp) != NULL) {
        parse_config_line(line, &config);
    }

    fclose(fp);

    apply_config(&config);

    *config_out = config;
    return CONFIG_VALID;
}

static void append_invalid_param(char *buf, size_t buf_size, const char *key) {
    strncat(buf, "\n", buf_size - strlen(buf) - 1);
    strncat(buf, key, buf_size - strlen(buf) - 1);
}

static void notify_invalid_params_if_changed(unsigned int defaults_used) {
    static unsigned int last_defaults_used = 0;
    char message[128] = "Invalid params:";

    if (defaults_used == last_defaults_used) {
        return;
    }

    last_defaults_used = defaults_used;
    if (defaults_used == 0) {
        return;
    }

    if (defaults_used & DEFAULT_USED_TARGET) {
        append_invalid_param(message, sizeof(message), "target_temperature");
    }
    if (defaults_used & DEFAULT_USED_ENABLE) {
        append_invalid_param(message, sizeof(message), "enable");
    }
    if (defaults_used & DEFAULT_USED_SHOW_STATUS) {
        append_invalid_param(message, sizeof(message), "show_status");
    }
    if (defaults_used & DEFAULT_USED_INTERVAL) {
        append_invalid_param(message, sizeof(message), "interval");
    }
    if (defaults_used & DEFAULT_USED_XMB_TARGET) {
        append_invalid_param(message, sizeof(message), "xmb_target_temperature");
    }
    if (defaults_used & DEFAULT_USED_FAHRENHEIT) {
        append_invalid_param(message, sizeof(message), "use_fahrenheit");
    }

    notify("[fan-control]\n%s", message);
}

static bool read_config(fan_config_t *config_out) {
    char path[64];
    config_read_result_t result;
    int i;

    for (i = 0; i < USB_MAX_COUNT; i++) {
        snprintf(path, sizeof(path), "/mnt/usb%d/fan_control.ini", i);
        result = read_config_from_path(path, config_out);
        if (result == CONFIG_VALID) {
            notify_invalid_params_if_changed(config_out->defaults_used);
            return true;
        }
    }

    result = read_config_from_path(DATA_CONFIG_PATH, config_out);
    if (result == CONFIG_VALID) {
        notify_invalid_params_if_changed(config_out->defaults_used);
        return true;
    }

    config_out->threshold = DEFAULT_THRESHOLD;
    config_out->threshold_raw = 0;
    config_out->interval = DEFAULT_INTERVAL_SECONDS;
    config_out->enable = true;
    config_out->show_status = false;
    config_out->xmb_threshold = 0;
    config_out->xmb_threshold_raw = 0;
    config_out->defaults_used = 0;
    config_out->use_fahrenheit = false;
    notify_invalid_params_if_changed(0);
    return true;
}

static bool set_fan_threshold(int threshold) {
    int fd;
    char data[10] = {0};

    data[5] = (char)threshold;

    fd = open(FAN_DEVICE, O_RDONLY, 0);
    if (fd < 0) {
        notify("[fan-control] Failed to open %s", FAN_DEVICE);
        return false;
    }

    if (ioctl(fd, FAN_IOCTL_SET_THRESHOLD, data) < 0) {
        close(fd);
        notify("[fan-control] Failed to set threshold");
        return false;
    }

    close(fd);
    return true;
}

static bool should_use_xmb_threshold(const fan_config_t *config)
{
    if (config->xmb_threshold > 0) {
        int id = sceSystemServiceGetAppIdOfRunningBigApp();

        return id <= 0;
    }

    return false;
}

static int get_current_threshold(const fan_config_t *config)
{
    if (should_use_xmb_threshold(config)) {
        return config->xmb_threshold;
    }

    return config->threshold;
}

static bool get_current_fan_percent(int *percent_out) {
    uint16_t raw_duty = 0;
    uint8_t scratch[64] = {0};
    int percent;

    if (sceKernelGetCurrentFanDuty(&raw_duty, scratch) != 0) {
        return false;
    }

    percent = raw_duty / 10;
    if (percent > 100) {
        percent = 100;
    }

    *percent_out = percent;
    return true;
}

static int celsius_to_fahrenheit(int celsius)
{
    return celsius * 9 / 5 + 32;
}

static void notify_status(const fan_config_t *config)
{
    int cpu_c = -1;
    int soc_c = -1;
    int fan_percent = -1;
    int cpu_temp_value;
    int soc_temp_value;
    int target_temp_value;
    char gpu_temp[16];
    char cpu_temp[16];
    char fan_target[16];
    char fan_speed[16];
    const char *unit_symbol;

    bool cpu_ok = (sceKernelGetCpuTemperature(&cpu_c) == 0 && cpu_c >= 0 && cpu_c <= 130);
    bool soc_ok = (sceKernelGetSocSensorTemperature(0, &soc_c) == 0 && soc_c >= 0 && soc_c <= 130);
    bool fan_ok = get_current_fan_percent(&fan_percent);

    unit_symbol = config->use_fahrenheit ? "℉" : "℃";

    cpu_temp_value = cpu_ok && config->use_fahrenheit ?
                     celsius_to_fahrenheit(cpu_c) :
                     cpu_c;
    soc_temp_value = soc_ok && config->use_fahrenheit ?
                     celsius_to_fahrenheit(soc_c) :
                     soc_c;

    if (config->use_fahrenheit && should_use_xmb_threshold(config)) {
        target_temp_value = config->xmb_threshold_raw;
    } else if (config->use_fahrenheit && !(config->defaults_used & DEFAULT_USED_TARGET)) {
        target_temp_value = config->threshold_raw;
    } else {
        target_temp_value = get_current_threshold(config);
    }
    if (config->use_fahrenheit && (config->defaults_used & DEFAULT_USED_TARGET)) {
        target_temp_value = celsius_to_fahrenheit(target_temp_value);
    }

    if (soc_ok) {
        snprintf(gpu_temp, sizeof(gpu_temp), "%d%s", soc_temp_value, unit_symbol);
    } else {
        snprintf(gpu_temp, sizeof(gpu_temp), "--%s", unit_symbol);
    }

    if (cpu_ok) {
        snprintf(cpu_temp, sizeof(cpu_temp), "%d%s", cpu_temp_value, unit_symbol);
    } else {
        snprintf(cpu_temp, sizeof(cpu_temp), "--%s", unit_symbol);
    }

    snprintf(fan_target, sizeof(fan_target), "%d%s", target_temp_value, unit_symbol);
    snprintf(fan_speed, sizeof(fan_speed), fan_ok ? "%d%%" : "--%%", fan_percent);

    notify("[fan-control]\nGPU %s\nCPU %s\nTARGET %s\nFAN %s",
           gpu_temp, cpu_temp, fan_target, fan_speed);
}

int main(void) {
    fan_config_t config;
    bool stopped;
    int sleep_seconds = DEFAULT_INTERVAL_SECONDS;

    syscall(SYS_thr_set_name, -1, PROCESS_NAME);

    if (!stop_previous_instances(&stopped)) {
        return 1;
    }
    notify(stopped ? "[fan-control] " VERSION_STRING "\nDaemon restarted" :
                     "[fan-control] " VERSION_STRING "\nDaemon started");

    if (read_config(&config) && config.enable) {
        set_fan_threshold(get_current_threshold(&config));
    }

    for (;;) {
        if (read_config(&config)) {
            sleep_seconds = config.interval;
            if (config.enable) {
                set_fan_threshold(get_current_threshold(&config));
            }
            if (config.show_status) {
                notify_status(&config);
            }
        } else {
            sleep_seconds = DEFAULT_INTERVAL_SECONDS;
        }

        sleep(sleep_seconds);
    }

    return 0;
}
